﻿using System;

namespace Kündigungsrechner
{
    class Program
    {

        static void Main()
        {

            Rechner rech = new Rechner();
            rech.Run();
        }


    }
}
